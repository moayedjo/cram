import React, { useState, useEffect } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Menu, X, Sun, Moon } from 'lucide-react';
import { useTheme } from '../../hooks/useTheme';
import { useLanguage } from '../../hooks/useLanguage';
import Logo from '../common/Logo';

export default function Header() {
  const { theme, toggleTheme } = useTheme();
  const { t } = useLanguage();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  
  // Toggle mobile menu
  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  
  // Handle scrolling effect
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  // Close menu when route changes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);
  
  return (
    <header 
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled 
          ? 'bg-white dark:bg-neutral-900 shadow-md py-2' 
          : 'bg-transparent py-4'
      }`}
    >
      <div className="container-custom flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="z-20">
          <Logo />
        </Link>
        
        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-8">
          <NavLink to="/" className={({ isActive }) => 
            `text-sm font-medium transition-colors hover:text-primary-600 dark:hover:text-primary-400 ${
              isActive ? 'text-primary-600 dark:text-primary-400' : 'text-neutral-800 dark:text-white'
            }`
          }>
            {t('nav.home')}
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => 
            `text-sm font-medium transition-colors hover:text-primary-600 dark:hover:text-primary-400 ${
              isActive ? 'text-primary-600 dark:text-primary-400' : 'text-neutral-800 dark:text-white'
            }`
          }>
            {t('nav.about')}
          </NavLink>
          <NavLink to="/services" className={({ isActive }) => 
            `text-sm font-medium transition-colors hover:text-primary-600 dark:hover:text-primary-400 ${
              isActive ? 'text-primary-600 dark:text-primary-400' : 'text-neutral-800 dark:text-white'
            }`
          }>
            {t('nav.services')}
          </NavLink>
          <NavLink to="/industries" className={({ isActive }) => 
            `text-sm font-medium transition-colors hover:text-primary-600 dark:hover:text-primary-400 ${
              isActive ? 'text-primary-600 dark:text-primary-400' : 'text-neutral-800 dark:text-white'
            }`
          }>
            {t('nav.industries')}
          </NavLink>
          <NavLink to="/insights" className={({ isActive }) => 
            `text-sm font-medium transition-colors hover:text-primary-600 dark:hover:text-primary-400 ${
              isActive ? 'text-primary-600 dark:text-primary-400' : 'text-neutral-800 dark:text-white'
            }`
          }>
            {t('nav.insights')}
          </NavLink>
          <NavLink to="/careers" className={({ isActive }) => 
            `text-sm font-medium transition-colors hover:text-primary-600 dark:hover:text-primary-400 ${
              isActive ? 'text-primary-600 dark:text-primary-400' : 'text-neutral-800 dark:text-white'
            }`
          }>
            {t('nav.careers')}
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => 
            `text-sm font-medium transition-colors hover:text-primary-600 dark:hover:text-primary-400 ${
              isActive ? 'text-primary-600 dark:text-primary-400' : 'text-neutral-800 dark:text-white'
            }`
          }>
            {t('nav.contact')}
          </NavLink>
        </nav>
        
        {/* Actions */}
        <div className="hidden lg:flex items-center space-x-4">
          {/* Theme Toggle */}
          <button 
            onClick={toggleTheme} 
            className="p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {theme === 'dark' ? (
              <Sun size={20} className="text-white" />
            ) : (
              <Moon size={20} className="text-neutral-700" />
            )}
          </button>
          
          {/* Contact Button */}
          <Link to="/contact" className="btn-primary">
            {t('nav.contact')}
          </Link>
        </div>
        
        {/* Mobile Menu Button */}
        <div className="lg:hidden flex items-center z-20">
          <button 
            onClick={toggleTheme} 
            className="p-2 mr-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {theme === 'dark' ? (
              <Sun size={20} className="text-white" />
            ) : (
              <Moon size={20} className="text-neutral-700" />
            )}
          </button>
          
          <button
            onClick={toggleMenu}
            className="p-2 rounded-md hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
          >
            {isMenuOpen ? (
              <X size={24} className={theme === 'dark' ? 'text-white' : 'text-neutral-700'} />
            ) : (
              <Menu size={24} className={theme === 'dark' ? 'text-white' : 'text-neutral-700'} />
            )}
          </button>
        </div>
        
        {/* Mobile Menu */}
        <div 
          className={`fixed inset-0 bg-white dark:bg-neutral-900 flex flex-col z-10 transition-transform duration-300 ease-in-out lg:hidden ${
            isMenuOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          <div className="h-20"></div>
          <div className="container-custom flex-1 flex flex-col py-8">
            <nav className="flex flex-col space-y-6 mt-8">
              <NavLink 
                to="/" 
                className={({ isActive }) => 
                  `text-lg font-medium ${isActive ? 'text-primary-600 dark:text-primary-400' : 'text-neutral-800 dark:text-white'}`
                }
              >
                {t('nav.home')}
              </NavLink>
              <NavLink 
                to="/about" 
                className={({ isActive }) => 
                  `text-lg font-medium ${isActive ? 'text-primary-600 dark:text-primary-400' : 'text-neutral-800 dark:text-white'}`
                }
              >
                {t('nav.about')}
              </NavLink>
              <NavLink 
                to="/services" 
                className={({ isActive }) => 
                  `text-lg font-medium ${isActive ? 'text-primary-600 dark:text-primary-400' : 'text-neutral-800 dark:text-white'}`
                }
              >
                {t('nav.services')}
              </NavLink>
              <NavLink 
                to="/industries" 
                className={({ isActive }) => 
                  `text-lg font-medium ${isActive ? 'text-primary-600 dark:text-primary-400' : 'text-neutral-800 dark:text-white'}`
                }
              >
                {t('nav.industries')}
              </NavLink>
              <NavLink 
                to="/insights" 
                className={({ isActive }) => 
                  `text-lg font-medium ${isActive ? 'text-primary-600 dark:text-primary-400' : 'text-neutral-800 dark:text-white'}`
                }
              >
                {t('nav.insights')}
              </NavLink>
              <NavLink 
                to="/careers" 
                className={({ isActive }) => 
                  `text-lg font-medium ${isActive ? 'text-primary-600 dark:text-primary-400' : 'text-neutral-800 dark:text-white'}`
                }
              >
                {t('nav.careers')}
              </NavLink>
              <NavLink 
                to="/contact" 
                className={({ isActive }) => 
                  `text-lg font-medium ${isActive ? 'text-primary-600 dark:text-primary-400' : 'text-neutral-800 dark:text-white'}`
                }
              >
                {t('nav.contact')}
              </NavLink>
            </nav>
            
            <div className="mt-auto">
              {/* Contact Button - Mobile */}
              <Link to="/contact" className="mt-4 btn-primary w-full flex justify-center">
                {t('nav.contact')}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}