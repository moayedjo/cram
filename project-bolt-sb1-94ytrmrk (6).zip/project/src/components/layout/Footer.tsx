import { Link } from 'react-router-dom';
import { Facebook, Twitter, Linkedin, Instagram, Mail, Phone, MapPin } from 'lucide-react';
import { useLanguage } from '../../hooks/useLanguage';
import Logo from '../common/Logo';

export default function Footer() {
  const { t } = useLanguage();
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-neutral-900 text-white pt-16 pb-8">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Column 1: Company Info */}
          <div>
            <div className="mb-4">
              <Logo variant="white" />
            </div>
            <p className="text-neutral-400 mb-6">
              {t('home.intro.subtitle')}
            </p>
            <div className="flex space-x-4 rtl:space-x-reverse">
              <a 
                href="https://facebook.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-white hover:text-primary-400 transition-colors"
                aria-label="Facebook"
              >
                <Facebook size={20} />
              </a>
              <a 
                href="https://twitter.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-white hover:text-primary-400 transition-colors"
                aria-label="Twitter"
              >
                <Twitter size={20} />
              </a>
              <a 
                href="https://linkedin.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-white hover:text-primary-400 transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin size={20} />
              </a>
              <a 
                href="https://instagram.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-white hover:text-primary-400 transition-colors"
                aria-label="Instagram"
              >
                <Instagram size={20} />
              </a>
            </div>
          </div>
          
          {/* Column 2: Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{t('nav.services')}</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/services" className="text-neutral-400 hover:text-white transition-colors">
                  {t('services.risk.title')}
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-neutral-400 hover:text-white transition-colors">
                  {t('services.diligence.title')}
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-neutral-400 hover:text-white transition-colors">
                  {t('services.cyber.title')}
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-neutral-400 hover:text-white transition-colors">
                  {t('services.aml.title')}
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-neutral-400 hover:text-white transition-colors">
                  {t('services.esg.title')}
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-neutral-400 hover:text-white transition-colors">
                  {t('services.investigation.title')}
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Column 3: Industries */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{t('nav.industries')}</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/industries" className="text-neutral-400 hover:text-white transition-colors">
                  {t('industries.financial.title')}
                </Link>
              </li>
              <li>
                <Link to="/industries" className="text-neutral-400 hover:text-white transition-colors">
                  {t('industries.government.title')}
                </Link>
              </li>
              <li>
                <Link to="/industries" className="text-neutral-400 hover:text-white transition-colors">
                  {t('industries.legal.title')}
                </Link>
              </li>
              <li>
                <Link to="/industries" className="text-neutral-400 hover:text-white transition-colors">
                  {t('industries.energy.title')}
                </Link>
              </li>
              <li>
                <Link to="/industries" className="text-neutral-400 hover:text-white transition-colors">
                  {t('industries.tech.title')}
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Column 4: Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{t('nav.contact')}</h4>
            <ul className="space-y-4">
              <li className="flex items-start space-x-2 rtl:space-x-reverse">
                <MapPin size={20} className="flex-shrink-0 mt-1 text-primary-400" />
                <span className="text-neutral-400">
                  {t('footer.address')}
                </span>
              </li>
              <li className="flex items-center space-x-2 rtl:space-x-reverse">
                <Phone size={20} className="flex-shrink-0 text-primary-400" />
                <a href="tel:+97140000000" className="text-neutral-400 hover:text-white transition-colors">
                  +971 4 000 0000
                </a>
              </li>
              <li className="flex items-center space-x-2 rtl:space-x-reverse">
                <Mail size={20} className="flex-shrink-0 text-primary-400" />
                <a href="mailto:info@cram-global.com" className="text-neutral-400 hover:text-white transition-colors">
                  info@cram-global.com
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        {/* Bottom Section */}
        <div className="pt-8 border-t border-neutral-800">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-neutral-500 text-sm mb-4 md:mb-0">
              &copy; {currentYear} CRAM. {t('footer.rights')}.
            </p>
            <div className="flex flex-wrap justify-center space-x-4 rtl:space-x-reverse text-sm">
              <Link to="/" className="text-neutral-500 hover:text-white transition-colors mb-2 md:mb-0">
                {t('footer.privacy')}
              </Link>
              <Link to="/" className="text-neutral-500 hover:text-white transition-colors mb-2 md:mb-0">
                {t('footer.terms')}
              </Link>
              <Link to="/" className="text-neutral-500 hover:text-white transition-colors mb-2 md:mb-0">
                {t('footer.cookies')}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}