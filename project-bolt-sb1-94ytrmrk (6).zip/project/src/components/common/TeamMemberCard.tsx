import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Linkedin } from 'lucide-react';

interface TeamMemberCardProps {
  name: string;
  position: string;
  imageUrl: string;
  linkedin?: string;
  delay?: number;
}

export default function TeamMemberCard({ 
  name, 
  position, 
  imageUrl,
  linkedin,
  delay = 0 
}: TeamMemberCardProps) {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });
  
  return (
    <motion.div
      ref={ref}
      className="card card-hover overflow-hidden"
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.5, delay: delay * 0.1 }}
    >
      <div className="relative overflow-hidden group aspect-[3/4]">
        <img 
          src={imageUrl} 
          alt={name} 
          className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-110"
        />
        
        {linkedin && (
          <div className="absolute inset-0 bg-primary-900/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
            <a 
              href={linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="text-white bg-primary-600 p-2 rounded-full hover:bg-primary-700 transition-colors"
              aria-label={`${name}'s LinkedIn profile`}
            >
              <Linkedin size={24} />
            </a>
          </div>
        )}
      </div>
      
      <div className="p-4 md:p-6">
        <h3 className="text-lg font-semibold mb-1">{name}</h3>
        <p className="text-neutral-600 dark:text-neutral-400">{position}</p>
      </div>
    </motion.div>
  );
}