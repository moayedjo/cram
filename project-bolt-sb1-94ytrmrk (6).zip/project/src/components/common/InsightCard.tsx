import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Clock } from 'lucide-react';
import { useLanguage } from '../../hooks/useLanguage';

interface InsightCardProps {
  title: string;
  excerpt: string;
  imageUrl: string;
  category: string;
  date: string;
  slug: string;
  index: number;
}

export default function InsightCard({ 
  title, 
  excerpt, 
  imageUrl,
  category,
  date,
  slug,
  index 
}: InsightCardProps) {
  const { t } = useLanguage();
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });
  
  return (
    <motion.div
      ref={ref}
      className="card card-hover overflow-hidden"
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Link to={`/insights/${slug}`} className="block">
        <div className="relative aspect-video overflow-hidden">
          <img 
            src={imageUrl} 
            alt={title} 
            className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
          />
          <div className="absolute top-4 left-4 bg-primary-600 text-white text-xs font-medium py-1 px-2 rounded">
            {category}
          </div>
        </div>
      </Link>
      
      <div className="p-6">
        <div className="flex items-center text-sm text-neutral-500 dark:text-neutral-400 mb-3">
          <Clock size={16} className="mr-1" />
          <span>
            {t('insights.date')} {date}
          </span>
        </div>
        
        <Link to={`/insights/${slug}`} className="block group">
          <h3 className="text-xl font-semibold mb-2 group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
            {title}
          </h3>
        </Link>
        
        <p className="text-neutral-600 dark:text-neutral-400 mb-4 line-clamp-3">
          {excerpt}
        </p>
        
        <Link 
          to={`/insights/${slug}`} 
          className="text-primary-600 dark:text-primary-400 font-medium hover:underline inline-flex items-center"
        >
          {t('general.readMore')}
          <svg 
            className="ml-1 rtl:rotate-180 w-4 h-4" 
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24" 
            xmlns="http://www.w3.org/2000/svg"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth="2" 
              d="M9 5l7 7-7 7"
            />
          </svg>
        </Link>
      </div>
    </motion.div>
  );
}