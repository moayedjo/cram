import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

interface IndustryCardProps {
  title: string;
  description: string;
  imageUrl: string;
  index: number;
}

export default function IndustryCard({ 
  title, 
  description, 
  imageUrl,
  index 
}: IndustryCardProps) {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });
  
  return (
    <motion.div
      ref={ref}
      className="group relative overflow-hidden rounded-lg h-64"
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
        style={{ backgroundImage: `url(${imageUrl})` }}
      />
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 to-transparent opacity-80" />
      
      {/* Content */}
      <div className="absolute inset-0 p-6 flex flex-col justify-end">
        <h3 className="text-white text-xl font-semibold mb-2">{title}</h3>
        <p className="text-neutral-200 text-sm mb-4 line-clamp-2">{description}</p>
        <Link 
          to="/industries" 
          className="text-white bg-primary-600 bg-opacity-90 hover:bg-opacity-100 py-2 px-4 rounded-md inline-flex items-center text-sm transition-colors w-fit"
        >
          Learn More
          <svg 
            className="ml-1 rtl:rotate-180 w-4 h-4" 
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24" 
            xmlns="http://www.w3.org/2000/svg"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth="2" 
              d="M9 5l7 7-7 7"
            />
          </svg>
        </Link>
      </div>
    </motion.div>
  );
}