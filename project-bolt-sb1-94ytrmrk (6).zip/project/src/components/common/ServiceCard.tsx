import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface ServiceCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  delay?: number;
}

export default function ServiceCard({ 
  title, 
  description, 
  icon: Icon,
  delay = 0 
}: ServiceCardProps) {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });
  
  return (
    <motion.div
      ref={ref}
      className="card card-hover h-full flex flex-col"
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.5, delay: delay * 0.1 }}
    >
      <div className="p-6 md:p-8 flex flex-col h-full">
        <div className="mb-4 flex items-center justify-center h-14 w-14 rounded-lg bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400">
          <Icon size={28} />
        </div>
        <h3 className="text-xl font-semibold mb-3">{title}</h3>
        <p className="text-neutral-600 dark:text-neutral-400 mb-4">{description}</p>
        <div className="mt-auto">
          <Link 
            to="/services" 
            className="text-primary-600 dark:text-primary-400 font-medium hover:underline inline-flex items-center"
          >
            Learn More
            <svg 
              className="ml-1 rtl:rotate-180 w-4 h-4" 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth="2" 
                d="M9 5l7 7-7 7"
              />
            </svg>
          </Link>
        </div>
      </div>
    </motion.div>
  );
}