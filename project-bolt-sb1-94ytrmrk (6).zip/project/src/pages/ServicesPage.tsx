import { 
  Shield, 
  Search, 
  Lock, 
  BarChart, 
  Leaf, 
  FileSearch, 
  AlertCircle,
  Network,
  BookOpen,
  Users,
  LifeBuoy,
  CircleDollarSign
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { useLanguage } from '../hooks/useLanguage';
import SectionTitle from '../components/common/SectionTitle';
import Button from '../components/common/Button';

export default function ServicesPage() {
  const { t } = useLanguage();
  
  const mainServices = [
    {
      title: t('services.risk.title'),
      description: t('services.risk.description'),
      icon: Shield,
      imageUrl: 'https://images.pexels.com/photos/7681121/pexels-photo-7681121.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      details: [
        'Enterprise Risk Management',
        'Operational Risk Assessment',
        'Strategic Risk Planning',
        'Risk Mitigation Strategies',
      ],
    },
    {
      title: t('services.diligence.title'),
      description: t('services.diligence.description'),
      icon: Search,
      imageUrl: 'https://images.pexels.com/photos/6476254/pexels-photo-6476254.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      details: [
        'Background Checks',
        'Pre-Investment Due Diligence',
        'Vendor Screening',
        'Integrity Due Diligence',
      ],
    },
    {
      title: t('services.cyber.title'),
      description: t('services.cyber.description'),
      icon: Lock,
      imageUrl: 'https://images.pexels.com/photos/5380642/pexels-photo-5380642.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      details: [
        'Vulnerability Assessment',
        'Penetration Testing',
        'Security Architecture Review',
        'Incident Response Planning',
      ],
    },
    {
      title: t('services.aml.title'),
      description: t('services.aml.description'),
      icon: BarChart,
      imageUrl: 'https://images.pexels.com/photos/8370752/pexels-photo-8370752.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      details: [
        'AML Program Design',
        'Compliance Monitoring',
        'Transaction Monitoring',
        'Regulatory Compliance',
      ],
    },
    {
      title: t('services.esg.title'),
      description: t('services.esg.description'),
      icon: Leaf,
      imageUrl: 'https://images.pexels.com/photos/3943716/pexels-photo-3943716.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      details: [
        'ESG Risk Assessment',
        'Sustainability Reporting',
        'ESG Due Diligence',
        'Governance Advisory',
      ],
    },
    {
      title: t('services.investigation.title'),
      description: t('services.investigation.description'),
      icon: FileSearch,
      imageUrl: 'https://images.pexels.com/photos/6863189/pexels-photo-6863189.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      details: [
        'Fraud Investigations',
        'Corporate Intelligence',
        'Asset Tracing',
        'Litigation Support',
      ],
    },
  ];
  
  const additionalServices = [
    {
      title: 'Fraud Prevention',
      description: 'Comprehensive fraud prevention strategies and controls.',
      icon: AlertCircle,
      imageUrl: 'https://images.pexels.com/photos/8370438/pexels-photo-8370438.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      title: 'Third-Party Risk Management',
      description: 'Assess and manage risks posed by your third-party relationships.',
      icon: Network,
      imageUrl: 'https://images.pexels.com/photos/7681893/pexels-photo-7681893.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      title: 'Regulatory Advisory',
      description: 'Navigate complex regulatory landscapes with expert guidance.',
      icon: BookOpen,
      imageUrl: 'https://images.pexels.com/photos/6077326/pexels-photo-6077326.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      title: 'Executive Protection',
      description: 'Tailored security solutions for high-profile individuals.',
      icon: Users,
      imageUrl: 'https://images.pexels.com/photos/8867431/pexels-photo-8867431.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      title: 'Crisis Management',
      description: 'Prepare for and respond to critical incidents and crises.',
      icon: LifeBuoy,
      imageUrl: 'https://images.pexels.com/photos/6476589/pexels-photo-6476589.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      title: 'Transaction Advisory',
      description: 'Risk assessment and due diligence for major transactions.',
      icon: CircleDollarSign,
      imageUrl: 'https://images.pexels.com/photos/7681122/pexels-photo-7681122.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
  ];
  
  return (
    <>
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 bg-neutral-900 text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ 
            backgroundImage: 'url(https://images.pexels.com/photos/3183183/pexels-photo-3183183.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)',
          }}
        />
        <div className="container-custom relative z-10">
          <h1 className="heading-1 mb-6">{t('nav.services')}</h1>
          <p className="text-xl text-neutral-300 max-w-3xl">
            CRAM provides comprehensive risk management and advisory services tailored to the unique challenges of the MENA region.
          </p>
        </div>
      </section>
      
      {/* Main Services Section */}
      <section className="py-16 md:py-24 bg-white dark:bg-neutral-900">
        <div className="container-custom">
          <SectionTitle 
            title="Our Core Services" 
            subtitle="Comprehensive solutions to protect your organization" 
            centered={true}
          />
          
          <div className="space-y-12 md:space-y-16">
            {mainServices.map((service, index) => {
              const [ref, inView] = useInView({
                triggerOnce: true,
                threshold: 0.1,
              });
              
              const isEven = index % 2 === 0;
              
              return (
                <motion.div
                  key={index}
                  ref={ref}
                  initial={{ opacity: 0, y: 30 }}
                  animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                  transition={{ duration: 0.5 }}
                  className={`grid md:grid-cols-2 gap-8 md:gap-12 items-center ${
                    isEven ? '' : 'md:flex-row-reverse'
                  }`}
                >
                  <div className={`${isEven ? 'md:order-1' : 'md:order-2'}`}>
                    <div className="flex items-center mb-4">
                      <div className="flex items-center justify-center h-14 w-14 rounded-lg bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400">
                        <service.icon size={28} />
                      </div>
                      <h2 className="text-2xl font-bold ml-4">{service.title}</h2>
                    </div>
                    
                    <p className="text-neutral-600 dark:text-neutral-400 mb-6">
                      {service.description}
                    </p>
                    
                    <ul className="space-y-2 mb-6">
                      {service.details.map((detail, i) => (
                        <li key={i} className="flex items-start">
                          <span className="text-primary-600 dark:text-primary-400 mr-2">•</span>
                          <span className="text-neutral-700 dark:text-neutral-300">{detail}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <Button to="/contact" variant="primary">
                      Request Consultation
                    </Button>
                  </div>
                  
                  <div className={`${isEven ? 'md:order-2' : 'md:order-1'} bg-neutral-100 dark:bg-neutral-800 rounded-lg overflow-hidden`}>
                    <img 
                      src={service.imageUrl}
                      alt={service.title}
                      className="w-full h-full object-cover aspect-video"
                    />
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
      
      {/* Additional Services Section */}
      <section className="py-16 md:py-24 bg-neutral-50 dark:bg-neutral-800">
        <div className="container-custom">
          <SectionTitle 
            title="Additional Services" 
            subtitle="Specialized solutions for specific needs" 
            centered={true}
          />
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {additionalServices.map((service, index) => {
              const [ref, inView] = useInView({
                triggerOnce: true,
                threshold: 0.1,
              });
              
              return (
                <motion.div
                  key={index}
                  ref={ref}
                  initial={{ opacity: 0, y: 30 }}
                  animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white dark:bg-neutral-900 p-6 rounded-lg shadow-sm overflow-hidden"
                >
                  <div className="relative aspect-video mb-6 rounded-lg overflow-hidden">
                    <img 
                      src={service.imageUrl}
                      alt={service.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                    <div className="absolute bottom-4 left-4 flex items-center">
                      <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400">
                        <service.icon size={20} />
                      </div>
                    </div>
                  </div>
                  
                  <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                  <p className="text-neutral-600 dark:text-neutral-400">
                    {service.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
      
      {/* Approach Section */}
      <section className="py-16 md:py-24 bg-white dark:bg-neutral-900">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="heading-2 mb-6">Our Approach</h2>
              <p className="text-neutral-600 dark:text-neutral-400 mb-6">
                At CRAM, we take a comprehensive and tailored approach to each client engagement. Our methodology combines deep regional expertise with global best practices to deliver solutions that address the unique challenges of the MENA region.
              </p>
              
              <div className="space-y-4 mb-8">
                <div className="flex items-start">
                  <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 flex items-center justify-center mt-1">
                    <span className="font-bold">1</span>
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-semibold mb-1">Assessment</h3>
                    <p className="text-neutral-600 dark:text-neutral-400">
                      We conduct a thorough assessment of your organization's risks, challenges, and objectives.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 flex items-center justify-center mt-1">
                    <span className="font-bold">2</span>
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-semibold mb-1">Strategy Development</h3>
                    <p className="text-neutral-600 dark:text-neutral-400">
                      We develop a customized strategy that addresses your specific needs and risk profile.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 flex items-center justify-center mt-1">
                    <span className="font-bold">3</span>
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-semibold mb-1">Implementation</h3>
                    <p className="text-neutral-600 dark:text-neutral-400">
                      Our experts work with your team to implement the solutions effectively.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 flex items-center justify-center mt-1">
                    <span className="font-bold">4</span>
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-semibold mb-1">Monitoring & Optimization</h3>
                    <p className="text-neutral-600 dark:text-neutral-400">
                      We continuously monitor and optimize our solutions to ensure ongoing effectiveness.
                    </p>
                  </div>
                </div>
              </div>
              
              <Button to="/contact" variant="primary">
                Discuss Your Needs
              </Button>
            </div>
            
            <div>
              <img 
                src="https://images.pexels.com/photos/3182773/pexels-photo-3182773.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Our Approach" 
                className="w-full h-auto rounded-lg"
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary-900 text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Enhance Your Risk Management?
          </h2>
          <p className="text-xl text-neutral-300 mb-8 max-w-2xl mx-auto">
            Contact our experts today to discuss how CRAM can help protect your organization from evolving risks.
          </p>
          <Button 
            to="/contact" 
            variant="secondary" 
            size="lg"
          >
            Request a Consultation
          </Button>
        </div>
      </section>
    </>
  );
}