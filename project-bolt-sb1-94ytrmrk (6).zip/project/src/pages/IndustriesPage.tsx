import { 
  Building2, 
  Landmark, 
  Scale, 
  Droplets, 
  Cpu,
  BadgeCheck,
  ShieldCheck,
  Clock,
  Globe,
  Briefcase
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { useLanguage } from '../hooks/useLanguage';
import SectionTitle from '../components/common/SectionTitle';
import Button from '../components/common/Button';

export default function IndustriesPage() {
  const { t } = useLanguage();
  
  const industries = [
    {
      title: t('industries.financial.title'),
      description: t('industries.financial.description'),
      imageUrl: 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      icon: Building2,
      challenges: [
        'Compliance with complex regulations',
        'AML and fraud prevention',
        'Cybersecurity threats',
        'Due diligence on clients and partners',
      ],
      solutions: [
        'Regulatory compliance programs',
        'AML and KYC solutions',
        'Cybersecurity assessment and protection',
        'Enhanced due diligence services',
      ],
    },
    {
      title: t('industries.government.title'),
      description: t('industries.government.description'),
      imageUrl: 'https://images.pexels.com/photos/1098479/pexels-photo-1098479.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      icon: Landmark,
      challenges: [
        'National security concerns',
        'Critical infrastructure protection',
        'Public sector integrity',
        'Vendor and contractor risk',
      ],
      solutions: [
        'Security risk assessments',
        'Infrastructure protection strategies',
        'Anti-corruption programs',
        'Third-party due diligence',
      ],
    },
    {
      title: t('industries.legal.title'),
      description: t('industries.legal.description'),
      imageUrl: 'https://images.pexels.com/photos/5668842/pexels-photo-5668842.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      icon: Scale,
      challenges: [
        'Complex litigation support',
        'Evidence gathering',
        'Asset tracing',
        'Expert witness testimony',
      ],
      solutions: [
        'Forensic investigations',
        'Litigation support services',
        'Asset tracing and recovery',
        'Expert witness services',
      ],
    },
    {
      title: t('industries.energy.title'),
      description: t('industries.energy.description'),
      imageUrl: 'https://images.pexels.com/photos/247763/pexels-photo-247763.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      icon: Droplets,
      challenges: [
        'Environmental compliance',
        'Supply chain security',
        'Critical infrastructure protection',
        'Political and regulatory risk',
      ],
      solutions: [
        'ESG compliance programs',
        'Supply chain risk management',
        'Infrastructure security planning',
        'Political risk advisory',
      ],
    },
    {
      title: t('industries.tech.title'),
      description: t('industries.tech.description'),
      imageUrl: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      icon: Cpu,
      challenges: [
        'Intellectual property protection',
        'Data privacy compliance',
        'Advanced cyber threats',
        'Rapid technology evolution',
      ],
      solutions: [
        'IP protection strategies',
        'Data privacy compliance programs',
        'Advanced cybersecurity services',
        'Technology risk assessment',
      ],
    },
  ];
  
  const otherIndustries = [
    {
      title: 'Healthcare',
      icon: BadgeCheck,
    },
    {
      title: 'Insurance',
      icon: ShieldCheck,
    },
    {
      title: 'Real Estate',
      icon: Briefcase,
    },
    {
      title: 'Hospitality',
      icon: Clock,
    },
    {
      title: 'International Organizations',
      icon: Globe,
    },
  ];
  
  return (
    <>
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 bg-neutral-900 text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ 
            backgroundImage: 'url(https://images.pexels.com/photos/1181354/pexels-photo-1181354.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)',
          }}
        />
        <div className="container-custom relative z-10">
          <h1 className="heading-1 mb-6">{t('nav.industries')}</h1>
          <p className="text-xl text-neutral-300 max-w-3xl">
            CRAM provides specialized risk advisory and intelligence services tailored to the unique challenges of different industries.
          </p>
        </div>
      </section>
      
      {/* Industries Section */}
      <section className="py-16 md:py-24 bg-white dark:bg-neutral-900">
        <div className="container-custom">
          <SectionTitle 
            title="Industries We Serve" 
            subtitle="Specialized expertise across key sectors" 
            centered={true}
          />
          
          <div className="space-y-16 md:space-y-24">
            {industries.map((industry, index) => {
              const [ref, inView] = useInView({
                triggerOnce: true,
                threshold: 0.1,
              });
              
              const isEven = index % 2 === 0;
              
              return (
                <motion.div
                  key={index}
                  ref={ref}
                  initial={{ opacity: 0, y: 30 }}
                  animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                  transition={{ duration: 0.5 }}
                  id={industry.title.toLowerCase().replace(/\s+/g, '-')}
                >
                  <div className={`grid md:grid-cols-2 gap-8 md:gap-12 items-center ${
                    isEven ? '' : 'md:flex-row-reverse'
                  }`}>
                    <div className={`${isEven ? 'md:order-1' : 'md:order-2'}`}>
                      <div className="flex items-center mb-6">
                        <div className="flex items-center justify-center h-14 w-14 rounded-lg bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400">
                          <industry.icon size={28} />
                        </div>
                        <h2 className="text-2xl font-bold ml-4">{industry.title}</h2>
                      </div>
                      
                      <p className="text-neutral-600 dark:text-neutral-400 mb-8">
                        {industry.description} Our team provides specialized solutions to address the unique challenges facing this sector in the MENA region.
                      </p>
                      
                      <div className="grid sm:grid-cols-2 gap-6 mb-8">
                        <div>
                          <h3 className="text-lg font-semibold mb-4 text-primary-600 dark:text-primary-400">Key Challenges</h3>
                          <ul className="space-y-2">
                            {industry.challenges.map((challenge, i) => (
                              <li key={i} className="flex items-start">
                                <span className="text-primary-600 dark:text-primary-400 mr-2">•</span>
                                <span className="text-neutral-700 dark:text-neutral-300">{challenge}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        <div>
                          <h3 className="text-lg font-semibold mb-4 text-primary-600 dark:text-primary-400">Our Solutions</h3>
                          <ul className="space-y-2">
                            {industry.solutions.map((solution, i) => (
                              <li key={i} className="flex items-start">
                                <span className="text-primary-600 dark:text-primary-400 mr-2">•</span>
                                <span className="text-neutral-700 dark:text-neutral-300">{solution}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                      
                      <Button to="/contact" variant="primary">
                        Discuss Your Needs
                      </Button>
                    </div>
                    
                    <div className={`${isEven ? 'md:order-2' : 'md:order-1'} rounded-lg overflow-hidden`}>
                      <img 
                        src={industry.imageUrl}
                        alt={industry.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
      
      {/* Other Industries Section */}
      <section className="py-16 md:py-24 bg-neutral-50 dark:bg-neutral-800">
        <div className="container-custom">
          <SectionTitle 
            title="Other Industries" 
            subtitle="We also serve clients across these sectors" 
            centered={true}
          />
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-6">
            {otherIndustries.map((industry, index) => {
              const [ref, inView] = useInView({
                triggerOnce: true,
                threshold: 0.1,
              });
              
              return (
                <motion.div
                  key={index}
                  ref={ref}
                  initial={{ opacity: 0, y: 20 }}
                  animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white dark:bg-neutral-900 p-6 rounded-lg text-center flex flex-col items-center"
                >
                  <div className="flex items-center justify-center h-14 w-14 rounded-full bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 mb-4">
                    <industry.icon size={24} />
                  </div>
                  <h3 className="text-lg font-semibold">{industry.title}</h3>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
      
      {/* Approach Section */}
      <section className="py-16 md:py-24 bg-white dark:bg-neutral-900">
        <div className="container-custom">
          <SectionTitle 
            title="Our Industry Approach" 
            subtitle="How we develop industry-specific solutions" 
            centered={true}
          />
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-neutral-50 dark:bg-neutral-800 p-6 rounded-lg">
              <div className="h-12 w-12 rounded-full bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 flex items-center justify-center mb-4">
                <span className="text-xl font-bold">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Industry Analysis</h3>
              <p className="text-neutral-600 dark:text-neutral-400">
                We conduct comprehensive analysis of industry-specific risks, regulations, and challenges to understand the unique context of your sector.
              </p>
            </div>
            
            <div className="bg-neutral-50 dark:bg-neutral-800 p-6 rounded-lg">
              <div className="h-12 w-12 rounded-full bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 flex items-center justify-center mb-4">
                <span className="text-xl font-bold">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Tailored Solutions</h3>
              <p className="text-neutral-600 dark:text-neutral-400">
                We develop customized solutions that address the specific risk profile and regulatory requirements of your industry.
              </p>
            </div>
            
            <div className="bg-neutral-50 dark:bg-neutral-800 p-6 rounded-lg">
              <div className="h-12 w-12 rounded-full bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 flex items-center justify-center mb-4">
                <span className="text-xl font-bold">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Specialized Expertise</h3>
              <p className="text-neutral-600 dark:text-neutral-400">
                We assign industry specialists with deep sector knowledge to ensure our solutions are relevant and effective for your specific needs.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary-900 text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Protect Your Business?
          </h2>
          <p className="text-xl text-neutral-300 mb-8 max-w-2xl mx-auto">
            Contact our industry experts to discuss your specific needs and discover how CRAM can help your organization navigate complex risks.
          </p>
          <Button 
            to="/contact" 
            variant="secondary" 
            size="lg"
          >
            Get in Touch
          </Button>
        </div>
      </section>
    </>
  );
}