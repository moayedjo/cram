import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Check, Target, Eye, Shield, Award, Users } from 'lucide-react';
import { useLanguage } from '../hooks/useLanguage';
import SectionTitle from '../components/common/SectionTitle';
import TeamMemberCard from '../components/common/TeamMemberCard';
import Button from '../components/common/Button';

export default function AboutPage() {
  const { t } = useLanguage();
  const [missionRef, missionInView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });
  
  const teamMembers = [
    {
      name: 'Ahmed Al Mansoori',
      position: 'Chief Executive Officer',
      imageUrl: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      linkedin: 'https://linkedin.com',
    },
    {
      name: 'Sarah Johnson',
      position: 'Chief Operating Officer',
      imageUrl: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      linkedin: 'https://linkedin.com',
    },
    {
      name: 'Mohammed Al Hashimi',
      position: 'Head of Risk Advisory',
      imageUrl: 'https://images.pexels.com/photos/2232981/pexels-photo-2232981.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      linkedin: 'https://linkedin.com',
    },
    {
      name: 'Lisa Chen',
      position: 'Chief Technology Officer',
      imageUrl: 'https://images.pexels.com/photos/789822/pexels-photo-789822.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      linkedin: 'https://linkedin.com',
    },
  ];
  
  return (
    <>
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 bg-neutral-900 text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ 
            backgroundImage: 'url(https://images.pexels.com/photos/1438072/pexels-photo-1438072.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)',
          }}
        />
        <div className="container-custom relative z-10">
          <h1 className="heading-1 mb-6">{t('nav.about')}</h1>
          <p className="text-xl text-neutral-300 max-w-3xl">
            CRAM is a leading provider of risk advisory, investigations, compliance, cybersecurity, and intelligence services, headquartered in Dubai, UAE.
          </p>
        </div>
      </section>
      
      {/* Mission & Vision Section */}
      <section 
        ref={missionRef} 
        className="py-16 md:py-24 bg-white dark:bg-neutral-900"
      >
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={missionInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.5 }}
              className="bg-neutral-50 dark:bg-neutral-800 p-8 md:p-10 rounded-lg"
            >
              <div className="flex items-center mb-4">
                <div className="bg-primary-100 dark:bg-primary-900 p-2 rounded-md text-primary-600 dark:text-primary-400 mr-3">
                  <Target size={28} />
                </div>
                <h2 className="text-2xl font-bold">{t('about.mission.title')}</h2>
              </div>
              <p className="text-neutral-600 dark:text-neutral-400">
                {t('about.mission.text')}
              </p>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={missionInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-neutral-50 dark:bg-neutral-800 p-8 md:p-10 rounded-lg"
            >
              <div className="flex items-center mb-4">
                <div className="bg-primary-100 dark:bg-primary-900 p-2 rounded-md text-primary-600 dark:text-primary-400 mr-3">
                  <Eye size={28} />
                </div>
                <h2 className="text-2xl font-bold">{t('about.vision.title')}</h2>
              </div>
              <p className="text-neutral-600 dark:text-neutral-400">
                {t('about.vision.text')}
              </p>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Values Section */}
      <section className="py-16 md:py-24 bg-neutral-50 dark:bg-neutral-800">
        <div className="container-custom">
          <SectionTitle 
            title={t('about.values.title')} 
            centered={true}
          />
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white dark:bg-neutral-900 p-6 md:p-8 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="bg-primary-100 dark:bg-primary-900 p-2 rounded-full text-primary-600 dark:text-primary-400 mr-3">
                  <Shield size={24} />
                </div>
                <h3 className="text-xl font-semibold">{t('about.values.integrity')}</h3>
              </div>
              <p className="text-neutral-600 dark:text-neutral-400">
                We operate with the highest ethical standards, ensuring honesty, transparency, and accountability in all our actions.
              </p>
            </div>
            
            <div className="bg-white dark:bg-neutral-900 p-6 md:p-8 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="bg-primary-100 dark:bg-primary-900 p-2 rounded-full text-primary-600 dark:text-primary-400 mr-3">
                  <Award size={24} />
                </div>
                <h3 className="text-xl font-semibold">{t('about.values.excellence')}</h3>
              </div>
              <p className="text-neutral-600 dark:text-neutral-400">
                We strive for excellence in everything we do, delivering the highest quality services to exceed our clients' expectations.
              </p>
            </div>
            
            <div className="bg-white dark:bg-neutral-900 p-6 md:p-8 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="bg-primary-100 dark:bg-primary-900 p-2 rounded-full text-primary-600 dark:text-primary-400 mr-3">
                  <Check size={24} />
                </div>
                <h3 className="text-xl font-semibold">{t('about.values.discretion')}</h3>
              </div>
              <p className="text-neutral-600 dark:text-neutral-400">
                We handle all client matters with the utmost confidentiality and discretion, protecting sensitive information.
              </p>
            </div>
            
            <div className="bg-white dark:bg-neutral-900 p-6 md:p-8 rounded-lg md:col-span-3">
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <div className="flex items-center mb-4">
                    <div className="bg-primary-100 dark:bg-primary-900 p-2 rounded-full text-primary-600 dark:text-primary-400 mr-3">
                      <Users size={24} />
                    </div>
                    <h3 className="text-xl font-semibold">{t('about.values.collaboration')}</h3>
                  </div>
                  <p className="text-neutral-600 dark:text-neutral-400">
                    We believe in the power of teamwork and collaboration, working closely with our clients to achieve the best results.
                  </p>
                </div>
                
                <div>
                  <div className="flex items-center mb-4">
                    <div className="bg-primary-100 dark:bg-primary-900 p-2 rounded-full text-primary-600 dark:text-primary-400 mr-3">
                      <Check size={24} />
                    </div>
                    <h3 className="text-xl font-semibold">{t('about.values.innovation')}</h3>
                  </div>
                  <p className="text-neutral-600 dark:text-neutral-400">
                    We continuously adapt and innovate to stay ahead of emerging threats and challenges in a rapidly changing world.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Team Section */}
      <section className="py-16 md:py-24 bg-white dark:bg-neutral-900">
        <div className="container-custom">
          <SectionTitle 
            title={t('about.team.title')} 
            subtitle={t('about.team.subtitle')} 
            centered={true}
          />
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
            {teamMembers.map((member, index) => (
              <TeamMemberCard
                key={index}
                name={member.name}
                position={member.position}
                imageUrl={member.imageUrl}
                linkedin={member.linkedin}
                delay={index}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* History Section */}
      <section className="py-16 md:py-24 bg-neutral-50 dark:bg-neutral-800">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="heading-2 mb-6">{t('about.history.title')}</h2>
              <p className="text-neutral-600 dark:text-neutral-400 mb-4">
                {t('about.history.text')}
              </p>
              <p className="text-neutral-600 dark:text-neutral-400 mb-6">
                Since our inception, we have grown to become one of the most trusted risk advisory firms in the region, serving clients across the Middle East, North Africa, and beyond. Our team of experts brings together decades of experience in risk management, intelligence, compliance, and cybersecurity.
              </p>
              <p className="text-neutral-600 dark:text-neutral-400 mb-8">
                Today, CRAM is recognized for our deep regional expertise, our commitment to excellence, and our ability to provide tailored solutions that address the unique challenges of the MENA region. We continue to expand our services and capabilities to meet the evolving needs of our clients.
              </p>
              <Button to="/contact" variant="primary">
                {t('nav.contact')}
              </Button>
            </div>
            
            <div>
              <img 
                src="https://images.pexels.com/photos/618079/pexels-photo-618079.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Dubai Skyline" 
                className="w-full h-auto rounded-lg"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}