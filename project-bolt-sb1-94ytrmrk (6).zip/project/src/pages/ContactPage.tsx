import { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Mail, Phone, MapPin, CheckCircle } from 'lucide-react';
import { useLanguage } from '../hooks/useLanguage';
import SectionTitle from '../components/common/SectionTitle';
import Button from '../components/common/Button';

export default function ContactPage() {
  const { t } = useLanguage();
  const [formSubmitted, setFormSubmitted] = useState(false);
  
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would normally handle the form submission
    // For now, we'll just simulate a successful submission
    setFormSubmitted(true);
  };
  
  return (
    <>
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 bg-neutral-900 text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ 
            backgroundImage: 'url(https://images.pexels.com/photos/323705/pexels-photo-323705.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)',
          }}
        />
        <div className="container-custom relative z-10">
          <h1 className="heading-1 mb-6">{t('contact.title')}</h1>
          <p className="text-xl text-neutral-300 max-w-3xl">
            {t('contact.subtitle')}
          </p>
        </div>
      </section>
      
      {/* Contact Form and Info Section */}
      <section 
        ref={ref}
        className="py-16 md:py-24 bg-white dark:bg-neutral-900"
      >
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="heading-3 mb-6">Send Us a Message</h2>
              
              {formSubmitted ? (
                <div className="bg-green-50 dark:bg-green-900/20 p-6 rounded-lg mb-6">
                  <div className="flex items-start">
                    <CheckCircle className="text-green-600 dark:text-green-400 mt-1" size={24} />
                    <div className="ml-4">
                      <h3 className="text-green-800 dark:text-green-300 font-medium text-lg mb-2">
                        Thank You!
                      </h3>
                      <p className="text-green-700 dark:text-green-400">
                        {t('contact.form.success')}
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label 
                        htmlFor="name" 
                        className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1"
                      >
                        {t('contact.form.name')} *
                      </label>
                      <input 
                        type="text" 
                        id="name" 
                        name="name"
                        required
                        className="w-full px-4 py-2 border border-neutral-300 dark:border-neutral-700 rounded-md bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                      />
                    </div>
                    
                    <div>
                      <label 
                        htmlFor="email" 
                        className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1"
                      >
                        {t('contact.form.email')} *
                      </label>
                      <input 
                        type="email" 
                        id="email" 
                        name="email"
                        required
                        className="w-full px-4 py-2 border border-neutral-300 dark:border-neutral-700 rounded-md bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                      />
                    </div>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label 
                        htmlFor="phone" 
                        className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1"
                      >
                        {t('contact.form.phone')}
                      </label>
                      <input 
                        type="tel" 
                        id="phone" 
                        name="phone"
                        className="w-full px-4 py-2 border border-neutral-300 dark:border-neutral-700 rounded-md bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                      />
                    </div>
                    
                    <div>
                      <label 
                        htmlFor="company" 
                        className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1"
                      >
                        {t('contact.form.company')}
                      </label>
                      <input 
                        type="text" 
                        id="company" 
                        name="company"
                        className="w-full px-4 py-2 border border-neutral-300 dark:border-neutral-700 rounded-md bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label 
                      htmlFor="subject" 
                      className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1"
                    >
                      {t('contact.form.subject')} *
                    </label>
                    <input 
                      type="text" 
                      id="subject" 
                      name="subject"
                      required
                      className="w-full px-4 py-2 border border-neutral-300 dark:border-neutral-700 rounded-md bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                  
                  <div>
                    <label 
                      htmlFor="message" 
                      className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1"
                    >
                      {t('contact.form.message')} *
                    </label>
                    <textarea 
                      id="message" 
                      name="message"
                      rows={5}
                      required
                      className="w-full px-4 py-2 border border-neutral-300 dark:border-neutral-700 rounded-md bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                  
                  <div>
                    <Button 
                      type="submit" 
                      variant="primary"
                      fullWidth={true}
                    >
                      {t('contact.form.submit')}
                    </Button>
                  </div>
                </form>
              )}
            </motion.div>
            
            {/* Contact Information */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <h2 className="heading-3 mb-6">{t('contact.office.title')}</h2>
              
              <div className="bg-neutral-50 dark:bg-neutral-800 p-6 rounded-lg mb-8">
                <h3 className="text-xl font-semibold mb-4">{t('contact.office.address')}</h3>
                
                <div className="space-y-4">
                  <div className="flex items-start">
                    <MapPin size={24} className="text-primary-600 dark:text-primary-400 flex-shrink-0 mt-1" />
                    <div className="ml-4">
                      <p className="text-neutral-700 dark:text-neutral-300">
                        {t('contact.office.location')}
                      </p>
                      <p className="text-neutral-700 dark:text-neutral-300">
                        {t('contact.office.city')}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <Phone size={24} className="text-primary-600 dark:text-primary-400 flex-shrink-0" />
                    <div className="ml-4">
                      <a 
                        href="tel:+97140000000" 
                        className="text-neutral-700 dark:text-neutral-300 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
                      >
                        {t('contact.office.phone')}
                      </a>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <Mail size={24} className="text-primary-600 dark:text-primary-400 flex-shrink-0" />
                    <div className="ml-4">
                      <a 
                        href="mailto:info@cram-global.com" 
                        className="text-neutral-700 dark:text-neutral-300 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
                      >
                        {t('contact.office.email')}
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Google Maps Embed */}
              <div className="rounded-lg overflow-hidden h-[300px]">
                <iframe 
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3609.0971352776717!2d55.27661221501281!3d25.235186983879766!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f42ebc9bc8a3f%3A0xdad9f1c8c86c7c99!2sDubai%20International%20Financial%20Centre%20-%20DIFC!5e0!3m2!1sen!2sus!4v1673902073997!5m2!1sen!2sus" 
                  width="100%" 
                  height="100%" 
                  style={{ border: 0 }} 
                  allowFullScreen={true} 
                  loading="lazy" 
                  referrerPolicy="no-referrer-when-downgrade"
                  title="CRAM Office Location"
                ></iframe>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
}