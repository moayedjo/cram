import { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Heart, Briefcase, Award, Globe, BookOpen, Users } from 'lucide-react';
import { useLanguage } from '../hooks/useLanguage';
import SectionTitle from '../components/common/SectionTitle';
import Button from '../components/common/Button';

interface JobPosition {
  title: string;
  location: string;
  type: string;
  department: string;
  description: string;
  requirements: string[];
  id: string;
}

export default function CareersPage() {
  const { t } = useLanguage();
  const [activePosition, setActivePosition] = useState<string | null>(null);
  
  const jobPositions: JobPosition[] = [
    {
      title: 'Senior Risk Consultant',
      location: 'Dubai, UAE',
      type: 'Full-time',
      department: 'Risk Advisory',
      description: 'We are seeking an experienced Risk Consultant to join our team in Dubai. The ideal candidate will have a strong background in enterprise risk management and experience working with financial institutions in the MENA region.',
      requirements: [
        'Minimum 7 years of experience in risk management',
        'Strong understanding of regional regulations',
        'Experience working with financial institutions',
        'Excellent analytical and communication skills',
        'Arabic language proficiency preferred',
      ],
      id: 'risk-consultant',
    },
    {
      title: 'Cybersecurity Analyst',
      location: 'Dubai, UAE',
      type: 'Full-time',
      department: 'Cybersecurity',
      description: 'CRAM is looking for a skilled Cybersecurity Analyst to help our clients protect their digital assets. This role involves conducting security assessments, penetration testing, and developing security strategies.',
      requirements: [
        'Minimum 5 years of experience in cybersecurity',
        'Relevant certifications (CISSP, CEH, CISM)',
        'Experience with security assessment tools',
        'Knowledge of threat intelligence and incident response',
        'Strong technical writing skills',
      ],
      id: 'cybersecurity-analyst',
    },
    {
      title: 'AML Compliance Specialist',
      location: 'Dubai, UAE',
      type: 'Full-time',
      department: 'Compliance',
      description: 'We are seeking an AML Compliance Specialist to support our financial institution clients. The role involves developing and implementing AML programs, conducting risk assessments, and ensuring regulatory compliance.',
      requirements: [
        'Minimum 5 years of experience in AML/compliance',
        'Strong knowledge of FATF standards and regional regulations',
        'Experience working with financial institutions',
        'Analytical mindset and attention to detail',
        'Excellent communication skills in English and Arabic',
      ],
      id: 'aml-specialist',
    },
    {
      title: 'Corporate Investigator',
      location: 'Dubai, UAE',
      type: 'Full-time',
      department: 'Investigations',
      description: 'CRAM is seeking a Corporate Investigator to conduct complex investigations for our clients. The role involves fraud investigations, due diligence, and asset tracing assignments.',
      requirements: [
        'Minimum 5 years of investigation experience',
        'Background in law enforcement, intelligence, or corporate investigations',
        'Experience in the MENA region',
        'Strong analytical and research skills',
        'Excellent report writing abilities',
      ],
      id: 'corporate-investigator',
    },
  ];
  
  const benefits = [
    {
      title: 'Competitive Compensation',
      description: 'We offer excellent salary packages and benefits tailored to attract and retain top talent.',
      icon: Briefcase,
    },
    {
      title: 'Healthcare Benefits',
      description: 'Comprehensive health insurance for you and your family.',
      icon: Heart,
    },
    {
      title: 'Professional Development',
      description: 'Ongoing training, certification support, and career advancement opportunities.',
      icon: Award,
    },
    {
      title: 'International Exposure',
      description: 'Work with clients and colleagues from around the world on diverse projects.',
      icon: Globe,
    },
    {
      title: 'Learning Opportunities',
      description: 'Access to industry conferences, workshops, and learning platforms.',
      icon: BookOpen,
    },
    {
      title: 'Collaborative Culture',
      description: 'Join a diverse team of professionals in a supportive work environment.',
      icon: Users,
    },
  ];
  
  const togglePosition = (id: string) => {
    if (activePosition === id) {
      setActivePosition(null);
    } else {
      setActivePosition(id);
    }
  };
  
  return (
    <>
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 bg-neutral-900 text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ 
            backgroundImage: 'url(https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)',
          }}
        />
        <div className="container-custom relative z-10">
          <h1 className="heading-1 mb-6">{t('careers.title')}</h1>
          <p className="text-xl text-neutral-300 max-w-3xl">
            {t('careers.subtitle')}
          </p>
        </div>
      </section>
      
      {/* Introduction Section */}
      <section className="py-16 md:py-24 bg-white dark:bg-neutral-900">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="heading-2 mb-6">Join Our Team of Experts</h2>
              <p className="text-neutral-600 dark:text-neutral-400 mb-6">
                {t('careers.text')} At CRAM, we're looking for talented individuals who are passionate about making a difference in the field of risk management and intelligence.
              </p>
              <p className="text-neutral-600 dark:text-neutral-400 mb-6">
                Based in Dubai, we offer an exciting work environment where you'll collaborate with industry experts, work on challenging projects, and develop your skills while contributing to the security and success of our clients.
              </p>
              <p className="text-neutral-600 dark:text-neutral-400 mb-6">
                We value diversity, innovation, and excellence, and we're committed to providing our team members with the support and opportunities they need to thrive in their careers.
              </p>
            </div>
            
            <div>
              <img 
                src="https://images.pexels.com/photos/3182781/pexels-photo-3182781.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="CRAM Team" 
                className="w-full h-auto rounded-lg"
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Benefits Section */}
      <section className="py-16 md:py-24 bg-neutral-50 dark:bg-neutral-800">
        <div className="container-custom">
          <SectionTitle 
            title={t('careers.benefits.title')} 
            centered={true}
          />
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {benefits.map((benefit, index) => {
              const [ref, inView] = useInView({
                triggerOnce: true,
                threshold: 0.1,
              });
              
              return (
                <motion.div
                  key={index}
                  ref={ref}
                  initial={{ opacity: 0, y: 30 }}
                  animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white dark:bg-neutral-900 p-6 rounded-lg"
                >
                  <div className="flex items-center mb-4">
                    <div className="flex items-center justify-center h-12 w-12 rounded-full bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400">
                      <benefit.icon size={24} />
                    </div>
                    <h3 className="text-xl font-semibold ml-4">{benefit.title}</h3>
                  </div>
                  
                  <p className="text-neutral-600 dark:text-neutral-400">
                    {benefit.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
      
      {/* Open Positions Section */}
      <section className="py-16 md:py-24 bg-white dark:bg-neutral-900">
        <div className="container-custom">
          <SectionTitle 
            title={t('careers.positions.title')} 
            centered={true}
          />
          
          <div className="space-y-6">
            {jobPositions.map((position) => {
              const isActive = activePosition === position.id;
              
              return (
                <div 
                  key={position.id}
                  className="border border-neutral-200 dark:border-neutral-700 rounded-lg overflow-hidden"
                >
                  <button
                    onClick={() => togglePosition(position.id)}
                    className="w-full p-6 flex flex-col md:flex-row md:items-center justify-between text-left bg-white dark:bg-neutral-900 hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors"
                    aria-expanded={isActive}
                  >
                    <div>
                      <h3 className="text-xl font-semibold mb-1">{position.title}</h3>
                      <div className="text-neutral-600 dark:text-neutral-400 flex flex-wrap gap-x-4">
                        <span>{position.location}</span>
                        <span>•</span>
                        <span>{position.type}</span>
                        <span>•</span>
                        <span>{position.department}</span>
                      </div>
                    </div>
                    <div className="mt-4 md:mt-0">
                      <span className={`inline-flex items-center justify-center h-8 w-8 rounded-full ${
                        isActive 
                          ? 'bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400' 
                          : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400'
                      }`}>
                        {isActive ? '−' : '+'}
                      </span>
                    </div>
                  </button>
                  
                  {isActive && (
                    <div className="p-6 border-t border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800">
                      <p className="text-neutral-600 dark:text-neutral-400 mb-4">
                        {position.description}
                      </p>
                      
                      <h4 className="text-lg font-semibold mb-2">Requirements:</h4>
                      <ul className="list-disc list-inside text-neutral-600 dark:text-neutral-400 mb-6">
                        {position.requirements.map((requirement, index) => (
                          <li key={index} className="mb-1">{requirement}</li>
                        ))}
                      </ul>
                      
                      <Button 
                        href={`mailto:careers@cram-global.com?subject=Application: ${position.title}`}
                        variant="primary"
                      >
                        Apply Now
                      </Button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>
      
      {/* How to Apply Section */}
      <section className="py-16 md:py-24 bg-neutral-50 dark:bg-neutral-800">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="heading-2 mb-6">{t('careers.apply.title')}</h2>
            <p className="text-neutral-600 dark:text-neutral-400 mb-6">
              {t('careers.apply.text')}
            </p>
            <p className="text-neutral-600 dark:text-neutral-400 mb-8">
              Please include the position you're applying for in the subject line. We'll review your application and contact you if your qualifications match our requirements.
            </p>
            <Button 
              href="mailto:careers@cram-global.com"
              variant="primary"
              size="lg"
            >
              Send Your Application
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}