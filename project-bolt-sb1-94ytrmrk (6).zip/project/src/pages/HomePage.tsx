import {
  Shield,
  Search,
  Lock,
  BarChart,
  Leaf,
  FileSearch,
  Building2,
  Landmark,
  Scale,
  Droplets,
  Cpu
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { useLanguage } from '../hooks/useLanguage';
import SectionTitle from '../components/common/SectionTitle';
import ServiceCard from '../components/common/ServiceCard';
import IndustryCard from '../components/common/IndustryCard';
import Button from '../components/common/Button';

export default function HomePage() {
  const { t } = useLanguage();
  const [heroRef, heroInView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });
  
  const services = [
    {
      title: t('services.risk.title'),
      description: t('services.risk.description'),
      icon: Shield,
    },
    {
      title: t('services.diligence.title'),
      description: t('services.diligence.description'),
      icon: Search,
    },
    {
      title: t('services.cyber.title'),
      description: t('services.cyber.description'),
      icon: Lock,
    },
    {
      title: t('services.aml.title'),
      description: t('services.aml.description'),
      icon: BarChart,
    },
    {
      title: t('services.esg.title'),
      description: t('services.esg.description'),
      icon: Leaf,
    },
    {
      title: t('services.investigation.title'),
      description: t('services.investigation.description'),
      icon: FileSearch,
    },
  ];
  
  const industries = [
    {
      title: t('industries.financial.title'),
      description: t('industries.financial.description'),
      imageUrl: 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      icon: Building2,
    },
    {
      title: t('industries.government.title'),
      description: t('industries.government.description'),
      imageUrl: 'https://images.pexels.com/photos/1098479/pexels-photo-1098479.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      icon: Landmark,
    },
    {
      title: t('industries.legal.title'),
      description: t('industries.legal.description'),
      imageUrl: 'https://images.pexels.com/photos/5668842/pexels-photo-5668842.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      icon: Scale,
    },
    {
      title: t('industries.energy.title'),
      description: t('industries.energy.description'),
      imageUrl: 'https://images.pexels.com/photos/247763/pexels-photo-247763.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      icon: Droplets,
    },
    {
      title: t('industries.tech.title'),
      description: t('industries.tech.description'),
      imageUrl: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      icon: Cpu,
    },
  ];
  
  return (
    <>
      {/* Hero Section */}
      <section 
        ref={heroRef}
        className="relative min-h-[80vh] flex items-center overflow-hidden"
      >
        {/* Background Image */}
        <div 
          className="absolute inset-0 bg-cover bg-center z-0"
          style={{ 
            backgroundImage: 'url(https://images.pexels.com/photos/1470405/pexels-photo-1470405.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)',
          }}
        />
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-primary-900/75 z-10" />
        
        {/* Content */}
        <div className="container-custom relative z-20 py-20">
          <div className="max-w-3xl">
            <motion.h1 
              className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6"
              initial={{ opacity: 0, y: 30 }}
              animate={heroInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.7 }}
            >
              {t('home.hero.title')}
            </motion.h1>
            
            <motion.p 
              className="text-xl text-neutral-200 mb-8 max-w-2xl"
              initial={{ opacity: 0, y: 30 }}
              animate={heroInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.7, delay: 0.1 }}
            >
              {t('home.hero.subtitle')}
            </motion.p>
            
            <motion.div 
              className="flex flex-wrap gap-4"
              initial={{ opacity: 0, y: 30 }}
              animate={heroInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <Button to="/services" variant="primary" size="lg">
                {t('home.hero.cta')}
              </Button>
              <Button to="/contact" variant="outline" size="lg" className="text-white border-white hover:bg-white/10 hover:text-white">
                {t('home.hero.contact')}
              </Button>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Intro Section */}
      <section className="py-16 md:py-24 bg-white dark:bg-neutral-900">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div>
              <SectionTitle 
                title={t('home.intro.title')} 
                subtitle={t('home.intro.subtitle')} 
                centered={false}
              />
              <p className="text-neutral-600 dark:text-neutral-400 mb-6">
                {t('home.intro.text')}
              </p>
              <Button to="/about" variant="primary">
                {t('general.learnMore')}
              </Button>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-primary-50 dark:bg-primary-900 p-6 rounded-lg text-center">
                <div className="text-3xl font-bold text-primary-600 dark:text-primary-400 mb-2">200+</div>
                <div className="text-neutral-600 dark:text-neutral-400">{t('home.stats.clients')}</div>
              </div>
              
              <div className="bg-primary-50 dark:bg-primary-900 p-6 rounded-lg text-center">
                <div className="text-3xl font-bold text-primary-600 dark:text-primary-400 mb-2">10+</div>
                <div className="text-neutral-600 dark:text-neutral-400">{t('home.stats.years')}</div>
              </div>
              
              <div className="bg-primary-50 dark:bg-primary-900 p-6 rounded-lg text-center">
                <div className="text-3xl font-bold text-primary-600 dark:text-primary-400 mb-2">50+</div>
                <div className="text-neutral-600 dark:text-neutral-400">{t('home.stats.experts')}</div>
              </div>
              
              <div className="bg-primary-50 dark:bg-primary-900 p-6 rounded-lg text-center">
                <div className="text-3xl font-bold text-primary-600 dark:text-primary-400 mb-2">20+</div>
                <div className="text-neutral-600 dark:text-neutral-400">{t('home.stats.countries')}</div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Services Section */}
      <section className="py-16 md:py-24 bg-neutral-50 dark:bg-neutral-800">
        <div className="container-custom">
          <SectionTitle 
            title={t('home.services.title')} 
            subtitle={t('home.services.subtitle')} 
            centered={true}
          />
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {services.map((service, index) => (
              <ServiceCard
                key={index}
                title={service.title}
                description={service.description}
                icon={service.icon}
                delay={index}
              />
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Button to="/services" variant="outline" size="lg">
              {t('general.viewAll')}
            </Button>
          </div>
        </div>
      </section>
      
      {/* Industries Section */}
      <section className="py-16 md:py-24 bg-white dark:bg-neutral-900">
        <div className="container-custom">
          <SectionTitle 
            title={t('home.industries.title')} 
            subtitle={t('home.industries.subtitle')} 
            centered={true}
          />
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {industries.slice(0, 3).map((industry, index) => (
              <IndustryCard
                key={index}
                title={industry.title}
                description={industry.description}
                imageUrl={industry.imageUrl}
                index={index}
              />
            ))}
          </div>
          
          <div className="grid sm:grid-cols-2 gap-6 mt-6">
            {industries.slice(3, 5).map((industry, index) => (
              <IndustryCard
                key={index + 3}
                title={industry.title}
                description={industry.description}
                imageUrl={industry.imageUrl}
                index={index + 3}
              />
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Button to="/industries" variant="outline" size="lg">
              {t('general.viewAll')}
            </Button>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary-900 text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            {t('home.cta.title')}
          </h2>
          <p className="text-xl text-neutral-300 mb-8 max-w-2xl mx-auto">
            {t('home.cta.text')}
          </p>
          <Button 
            to="/contact" 
            variant="secondary" 
            size="lg"
          >
            {t('home.cta.button')}
          </Button>
        </div>
      </section>
    </>
  );
}