import { Link } from 'react-router-dom';
import { useLanguage } from '../hooks/useLanguage';
import Button from '../components/common/Button';

export default function NotFoundPage() {
  const { t } = useLanguage();
  
  return (
    <section className="py-20 md:py-32 bg-white dark:bg-neutral-900">
      <div className="container-custom">
        <div className="max-w-md mx-auto text-center">
          <h1 className="text-9xl font-bold text-primary-600 dark:text-primary-400 mb-6">404</h1>
          <h2 className="text-3xl font-bold mb-4">{t('404.title')}</h2>
          <p className="text-neutral-600 dark:text-neutral-400 mb-8">
            {t('404.text')}
          </p>
          <Button to="/" variant="primary" size="lg">
            {t('404.button')}
          </Button>
        </div>
      </div>
    </section>
  );
}