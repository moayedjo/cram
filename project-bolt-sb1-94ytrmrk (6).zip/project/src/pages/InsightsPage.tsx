import { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { useLanguage } from '../hooks/useLanguage';
import SectionTitle from '../components/common/SectionTitle';
import InsightCard from '../components/common/InsightCard';
import Button from '../components/common/Button';

type InsightCategory = 'all' | 'articles' | 'news' | 'reports' | 'whitepapers';

interface Insight {
  title: string;
  excerpt: string;
  imageUrl: string;
  category: InsightCategory;
  date: string;
  slug: string;
}

export default function InsightsPage() {
  const { t } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<InsightCategory>('all');
  
  const insightsData: Insight[] = [
    {
      title: 'The Growing Cybersecurity Threats in the MENA Region',
      excerpt: 'An in-depth analysis of the evolving cybersecurity landscape in the Middle East and North Africa, highlighting key threats and mitigation strategies.',
      imageUrl: 'https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'reports',
      date: 'June 15, 2024',
      slug: 'cybersecurity-threats-mena',
    },
    {
      title: 'ESG Compliance: A New Frontier for MENA Businesses',
      excerpt: 'How companies in the Middle East are adapting to new Environmental, Social, and Governance (ESG) standards and expectations.',
      imageUrl: 'https://images.pexels.com/photos/3943716/pexels-photo-3943716.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'articles',
      date: 'May 28, 2024',
      slug: 'esg-compliance-mena',
    },
    {
      title: 'CRAM Expands Operations to Saudi Arabia',
      excerpt: 'CRAM announces the opening of a new office in Riyadh, extending its risk advisory and intelligence services to clients in Saudi Arabia.',
      imageUrl: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'news',
      date: 'May 10, 2024',
      slug: 'cram-expands-saudi-arabia',
    },
    {
      title: 'Anti-Money Laundering Best Practices for Financial Institutions',
      excerpt: 'A comprehensive guide to AML compliance for banks and financial institutions operating in the MENA region.',
      imageUrl: 'https://images.pexels.com/photos/8370752/pexels-photo-8370752.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'whitepapers',
      date: 'April 22, 2024',
      slug: 'aml-best-practices',
    },
    {
      title: 'Navigating Geopolitical Risks in International Business',
      excerpt: 'How multinational corporations can identify, assess, and mitigate geopolitical risks in their global operations.',
      imageUrl: 'https://images.pexels.com/photos/7788009/pexels-photo-7788009.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'articles',
      date: 'April 8, 2024',
      slug: 'geopolitical-risks-business',
    },
    {
      title: 'The Rise of Corporate Fraud in the Post-Pandemic Era',
      excerpt: 'Examining the increasing incidence of corporate fraud and the strategies organizations can employ to protect themselves.',
      imageUrl: 'https://images.pexels.com/photos/6863189/pexels-photo-6863189.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'reports',
      date: 'March 15, 2024',
      slug: 'corporate-fraud-post-pandemic',
    },
    {
      title: 'CRAM Partners with Global Security Alliance',
      excerpt: 'CRAM announces a strategic partnership with the Global Security Alliance to enhance cyber threat intelligence capabilities.',
      imageUrl: 'https://images.pexels.com/photos/4100653/pexels-photo-4100653.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'news',
      date: 'March 3, 2024',
      slug: 'cram-partnership-gsa',
    },
    {
      title: 'Due Diligence in Emerging Markets: A Practical Guide',
      excerpt: 'Essential considerations and methodologies for conducting effective due diligence in emerging markets.',
      imageUrl: 'https://images.pexels.com/photos/6694543/pexels-photo-6694543.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'whitepapers',
      date: 'February 20, 2024',
      slug: 'due-diligence-emerging-markets',
    },
    {
      title: 'Cybersecurity Trends to Watch in 2024',
      excerpt: 'The top cybersecurity developments and threats that organizations should be prepared for in the coming year.',
      imageUrl: 'https://images.pexels.com/photos/5380642/pexels-photo-5380642.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'articles',
      date: 'January 15, 2024',
      slug: 'cybersecurity-trends-2024',
    },
  ];
  
  const filteredInsights = activeCategory === 'all' 
    ? insightsData 
    : insightsData.filter(insight => insight.category === activeCategory);
  
  const categories = [
    { value: 'all', label: t('insights.categories.all') },
    { value: 'articles', label: t('insights.categories.articles') },
    { value: 'news', label: t('insights.categories.news') },
    { value: 'reports', label: t('insights.categories.reports') },
    { value: 'whitepapers', label: t('insights.categories.whitepapers') },
  ];
  
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });
  
  return (
    <>
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 bg-neutral-900 text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ 
            backgroundImage: 'url(https://images.pexels.com/photos/6348119/pexels-photo-6348119.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)',
          }}
        />
        <div className="container-custom relative z-10">
          <h1 className="heading-1 mb-6">{t('insights.title')}</h1>
          <p className="text-xl text-neutral-300 max-w-3xl">
            {t('insights.subtitle')}
          </p>
        </div>
      </section>
      
      {/* Insights Section */}
      <section className="py-16 md:py-24 bg-white dark:bg-neutral-900">
        <div className="container-custom">
          {/* Category Filter */}
          <div 
            ref={ref}
            className="flex flex-wrap items-center justify-center gap-2 mb-12"
          >
            {categories.map((category, index) => (
              <motion.button
                key={category.value}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  activeCategory === category.value
                    ? 'bg-primary-600 text-white'
                    : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700'
                }`}
                onClick={() => setActiveCategory(category.value as InsightCategory)}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                {category.label}
              </motion.button>
            ))}
          </div>
          
          {/* Insights Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {filteredInsights.map((insight, index) => (
              <InsightCard
                key={insight.slug}
                title={insight.title}
                excerpt={insight.excerpt}
                imageUrl={insight.imageUrl}
                category={t(`insights.categories.${insight.category}`)}
                date={insight.date}
                slug={insight.slug}
                index={index}
              />
            ))}
          </div>
          
          {/* Empty State */}
          {filteredInsights.length === 0 && (
            <div className="text-center py-16">
              <h3 className="text-xl font-semibold mb-4">No insights found</h3>
              <p className="text-neutral-600 dark:text-neutral-400 mb-6">
                No insights are currently available in this category.
              </p>
              <Button 
                onClick={() => setActiveCategory('all')} 
                variant="primary"
              >
                View All Insights
              </Button>
            </div>
          )}
          
          {/* Subscribe Section */}
          <div className="mt-16 bg-neutral-50 dark:bg-neutral-800 p-8 md:p-12 rounded-lg">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">Stay Updated</h2>
              <p className="text-neutral-600 dark:text-neutral-400 mb-8">
                Subscribe to our newsletter to receive the latest insights, reports, and news from CRAM.
              </p>
              
              <form className="max-w-md mx-auto">
                <div className="flex flex-col sm:flex-row gap-3">
                  <input 
                    type="email" 
                    placeholder="Your email address" 
                    className="flex-grow px-4 py-2 border border-neutral-300 dark:border-neutral-700 rounded-md bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                    required
                  />
                  <Button type="submit" variant="primary">
                    Subscribe
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}