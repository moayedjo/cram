import React, { createContext, useState, useEffect } from 'react';
import { translations } from '../locales';

type Language = 'en';

interface LanguageContextType {
  language: Language;
  t: (key: keyof typeof translations.en) => string;
}

export const LanguageContext = createContext<LanguageContextType>({
  language: 'en',
  t: () => '',
});

interface LanguageProviderProps {
  children: React.ReactNode;
}

export function LanguageProvider({ children }: LanguageProviderProps) {
  const [language] = useState<Language>('en');
  
  // Translation function
  const t = (key: keyof typeof translations.en): string => {
    return translations.en[key] || key;
  };
  
  return (
    <LanguageContext.Provider value={{ language, t }}>
      {children}
    </LanguageContext.Provider>
  );
}