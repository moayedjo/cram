import { en } from './en';

export const translations = {
  en,
};