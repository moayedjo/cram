export const en = {
  // Navigation
  'nav.home': 'Home',
  'nav.about': 'About Us',
  'nav.services': 'Services',
  'nav.industries': 'Industries',
  'nav.insights': 'Insights',
  'nav.careers': 'Careers',
  'nav.contact': 'Contact',
  
  // Footer
  'footer.rights': 'All Rights Reserved',
  'footer.privacy': 'Privacy Policy',
  'footer.terms': 'Terms of Service',
  'footer.cookies': 'Cookie Policy',
  'footer.contact': 'Contact Us',
  'footer.address': 'CRAM Headquarters, Dubai International Financial Centre, Dubai, UAE',
  
  // Home
  'home.hero.title': 'Expert Risk Advisory & Intelligence Services',
  'home.hero.subtitle': 'CRAM provides trusted intelligence and advisory services to governments, financial institutions, and multinational corporations across the MENA region.',
  'home.hero.cta': 'Discover Our Services',
  'home.hero.contact': 'Contact Us',
  
  'home.intro.title': 'Why Choose CRAM',
  'home.intro.subtitle': 'CRAM is a leading provider of risk management, compliance, and intelligence services in the Middle East.',
  'home.intro.text': 'With decades of combined experience and deep regional expertise, our team delivers tailored solutions that meet the unique challenges of the MENA region.',
  
  'home.stats.clients': 'Clients',
  'home.stats.years': 'Years Experience',
  'home.stats.experts': 'Experts',
  'home.stats.countries': 'Countries',
  
  'home.services.title': 'Our Services',
  'home.services.subtitle': 'Comprehensive solutions to protect your organization',
  
  'home.industries.title': 'Industries We Serve',
  'home.industries.subtitle': 'Specialized expertise across key sectors',
  
  'home.testimonials.title': 'What Our Clients Say',
  'home.testimonials.subtitle': 'Trusted by leading organizations',
  
  'home.cta.title': 'Ready to Secure Your Business?',
  'home.cta.text': 'Contact our experts for a consultation',
  'home.cta.button': 'Get Started',
  
  // Services
  'services.risk.title': 'Risk Management',
  'services.risk.description': 'Comprehensive risk assessment and mitigation strategies tailored to your organization.',
  
  'services.diligence.title': 'Due Diligence',
  'services.diligence.description': 'Thorough investigation and verification of potential business partners and investments.',
  
  'services.cyber.title': 'Cybersecurity',
  'services.cyber.description': 'Advanced protection against cyber threats and data breaches.',
  
  'services.aml.title': 'Anti-Money Laundering',
  'services.aml.description': 'Compliance solutions to detect and prevent financial crimes.',
  
  'services.esg.title': 'ESG Compliance',
  'services.esg.description': 'Environmental, Social, and Governance advisory services.',
  
  'services.investigation.title': 'Corporate Investigations',
  'services.investigation.description': 'Discreet and professional investigation services.',
  
  // Industries
  'industries.financial.title': 'Financial Services',
  'industries.financial.description': 'Solutions for banks, investment firms, and financial institutions.',
  
  'industries.government.title': 'Government',
  'industries.government.description': 'Supporting public sector organizations with specialized services.',
  
  'industries.legal.title': 'Legal',
  'industries.legal.description': 'Assisting law firms with investigations and risk management.',
  
  'industries.energy.title': 'Energy',
  'industries.energy.description': 'Risk management for oil, gas, and renewable energy companies.',
  
  'industries.tech.title': 'Technology',
  'industries.tech.description': 'Cybersecurity and compliance solutions for tech companies.',
  
  // About
  'about.mission.title': 'Our Mission',
  'about.mission.text': 'To provide unparalleled risk advisory and intelligence services that protect our clients and enable secure operations in complex environments.',
  
  'about.vision.title': 'Our Vision',
  'about.vision.text': 'To be the most trusted risk advisory firm in the MENA region, known for excellence, integrity, and innovation.',
  
  'about.values.title': 'Our Values',
  'about.values.integrity': 'Integrity',
  'about.values.excellence': 'Excellence',
  'about.values.innovation': 'Innovation',
  'about.values.discretion': 'Discretion',
  'about.values.collaboration': 'Collaboration',
  
  'about.team.title': 'Leadership Team',
  'about.team.subtitle': 'Expert professionals with deep industry experience',
  
  'about.history.title': 'Our History',
  'about.history.text': 'CRAM was founded in 2015 by a team of risk management professionals with extensive experience in the MENA region.',
  
  // Contact
  'contact.title': 'Contact Us',
  'contact.subtitle': 'Get in touch with our experts',
  'contact.form.name': 'Full Name',
  'contact.form.email': 'Email Address',
  'contact.form.phone': 'Phone Number',
  'contact.form.company': 'Company',
  'contact.form.subject': 'Subject',
  'contact.form.message': 'Message',
  'contact.form.submit': 'Send Message',
  'contact.form.success': 'Thank you for your message. We will get back to you shortly.',
  
  'contact.office.title': 'Our Office',
  'contact.office.address': 'CRAM Headquarters',
  'contact.office.location': 'Dubai International Financial Centre',
  'contact.office.city': 'Dubai, UAE',
  'contact.office.phone': '+971 4 000 0000',
  'contact.office.email': 'info@cram-global.com',
  
  // Careers
  'careers.title': 'Join Our Team',
  'careers.subtitle': 'Career opportunities at CRAM',
  'careers.text': 'We are always looking for talented professionals to join our growing team.',
  'careers.benefits.title': 'Benefits of Working at CRAM',
  'careers.positions.title': 'Open Positions',
  'careers.apply.title': 'How to Apply',
  'careers.apply.text': 'Please send your resume and cover letter to careers@cram-global.com',
  
  // Insights
  'insights.title': 'Insights & News',
  'insights.subtitle': 'Latest updates, articles, and reports',
  'insights.categories.all': 'All',
  'insights.categories.articles': 'Articles',
  'insights.categories.news': 'News',
  'insights.categories.reports': 'Reports',
  'insights.categories.whitepapers': 'Whitepapers',
  'insights.readmore': 'Read More',
  'insights.date': 'Published on',
  
  // 404
  '404.title': 'Page Not Found',
  '404.text': 'The page you are looking for does not exist.',
  '404.button': 'Return Home',
  
  // General
  'general.learnMore': 'Learn More',
  'general.readMore': 'Read More',
  'general.viewAll': 'View All',
  'general.loading': 'Loading...',
  'general.required': 'Required',
  'general.or': 'or',
  'general.and': 'and',
};