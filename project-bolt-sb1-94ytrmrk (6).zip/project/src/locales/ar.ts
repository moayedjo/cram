export const ar = {
  // Navigation
  'nav.home': 'الرئيسية',
  'nav.about': 'من نحن',
  'nav.services': 'خدماتنا',
  'nav.industries': 'القطاعات',
  'nav.insights': 'الرؤى',
  'nav.careers': 'الوظائف',
  'nav.contact': 'اتصل بنا',
  
  // Footer
  'footer.rights': 'جميع الحقوق محفوظة',
  'footer.privacy': 'سياسة الخصوصية',
  'footer.terms': 'الشروط والأحكام',
  'footer.cookies': 'سياسة ملفات تعريف الارتباط',
  'footer.contact': 'اتصل بنا',
  'footer.address': 'مركز دبي المالي العالمي، دبي، الإمارات العربية المتحدة',
  
  // Home
  'home.hero.title': 'خدمات استشارية متخصصة في إدارة المخاطر والذكاء الاستخباراتي',
  'home.hero.subtitle': 'نقدم خدمات استخباراتية واستشارية موثوقة للحكومات والمؤسسات المالية والشركات في منطقة الشرق الأوسط وشمال أفريقيا',
  'home.hero.cta': 'تعرف على خدماتنا',
  'home.hero.contact': 'تواصل معنا',
  
  'home.intro.title': 'لماذا كرام؟',
  'home.intro.subtitle': 'شريكك الموثوق في إدارة المخاطر والامتثال في الشرق الأوسط',
  'home.intro.text': 'نجمع بين الخبرة الإقليمية العميقة والمعرفة العالمية لتقديم حلول مخصصة تلبي التحديات الفريدة في المنطقة',
  
  'home.stats.clients': 'عميل',
  'home.stats.years': 'سنوات خبرة',
  'home.stats.experts': 'خبير',
  'home.stats.countries': 'دولة',
  
  'home.services.title': 'خدماتنا',
  'home.services.subtitle': 'حلول شاملة لحماية مؤسستك',
  
  'home.industries.title': 'القطاعات التي نخدمها',
  'home.industries.subtitle': 'خبرة متخصصة في القطاعات الرئيسية',
  
  'home.testimonials.title': 'ما يقوله عملاؤنا',
  'home.testimonials.subtitle': 'شهادات من مؤسسات رائدة',
  
  'home.cta.title': 'هل أنت جاهز لتأمين أعمالك؟',
  'home.cta.text': 'تواصل مع خبرائنا للاستشارة',
  'home.cta.button': 'ابدأ الآن',
  
  // Services
  'services.risk.title': 'عملية التقييم المتبادل والمتابعة',
  'services.risk.description': 'خدمات شاملة للإعداد والتنفيذ والمتابعة لعمليات التقييم المتبادل',
  
  'services.diligence.title': 'الإعداد للتقييم المتبادل',
  'services.diligence.description': 'برامج تدريبية متخصصة وإعداد المنسقين الوطنيين وفرق العمل',
  
  'services.cyber.title': 'تقييم المخاطر الوطني والقطاعي',
  'services.cyber.description': 'تحليل وتقييم شامل للمخاطر على المستوى الوطني والقطاعي',
  
  'services.aml.title': 'الاستراتيجيات وخطط العمل الوطنية',
  'services.aml.description': 'تطوير وتنفيذ استراتيجيات وخطط عمل وطنية فعالة',
  
  'services.esg.title': 'خدمات تقنية المعلومات',
  'services.esg.description': 'حلول تقنية متكاملة لدعم عمليات الامتثال والرقابة',
  
  'services.investigation.title': 'خدمات التحقيق المالي الموازي',
  'services.investigation.description': 'دعم متخصص في عمليات التحقيق المالي والتتبع',
  
  // Industries
  'industries.financial.title': 'الخدمات المالية',
  'industries.financial.description': 'حلول متكاملة للبنوك والمؤسسات المالية',
  
  'industries.government.title': 'القطاع الحكومي',
  'industries.government.description': 'دعم المؤسسات الحكومية بخدمات متخصصة',
  
  'industries.legal.title': 'القطاع القانوني',
  'industries.legal.description': 'مساندة المكاتب القانونية في التحقيقات وإدارة المخاطر',
  
  'industries.energy.title': 'الطاقة',
  'industries.energy.description': 'إدارة المخاطر لشركات النفط والغاز والطاقة المتجددة',
  
  'industries.tech.title': 'التكنولوجيا',
  'industries.tech.description': 'حلول الأمن السيبراني والامتثال لشركات التقنية',
  
  // About
  'about.mission.title': 'رسالتنا',
  'about.mission.text': 'تقديم خدمات استشارية واستخباراتية رائدة في مجال المخاطر لحماية عملائنا وتمكين العمليات الآمنة',
  
  'about.vision.title': 'رؤيتنا',
  'about.vision.text': 'أن نكون الشريك الأكثر موثوقية في استشارات المخاطر في منطقة الشرق الأوسط وشمال أفريقيا',
  
  'about.values.title': 'قيمنا',
  'about.values.integrity': 'النزاهة',
  'about.values.excellence': 'التميز',
  'about.values.innovation': 'الابتكار',
  'about.values.discretion': 'السرية',
  'about.values.collaboration': 'التعاون',
  
  'about.team.title': 'فريق القيادة',
  'about.team.subtitle': 'خبراء متخصصون بخبرة عميقة في القطاع',
  
  'about.history.title': 'تاريخنا',
  'about.history.text': 'تأسست كرام في عام 2015 على يد فريق من المتخصصين في إدارة المخاطر بخبرة واسعة في المنطقة',
  
  // Contact
  'contact.title': 'اتصل بنا',
  'contact.subtitle': 'تواصل مع خبرائنا',
  'contact.form.name': 'الاسم الكامل',
  'contact.form.email': 'البريد الإلكتروني',
  'contact.form.phone': 'رقم الهاتف',
  'contact.form.company': 'الشركة',
  'contact.form.subject': 'الموضوع',
  'contact.form.message': 'الرسالة',
  'contact.form.submit': 'إرسال',
  'contact.form.success': 'شكراً لتواصلك معنا. سنرد عليك قريباً',
  
  'contact.office.title': 'مكتبنا',
  'contact.office.address': 'المقر الرئيسي لكرام',
  'contact.office.location': 'مركز دبي المالي العالمي',
  'contact.office.city': 'دبي، الإمارات العربية المتحدة',
  'contact.office.phone': '+971 4 000 0000',
  'contact.office.email': 'info@cram-global.com',
  
  // Careers
  'careers.title': 'انضم إلى فريقنا',
  'careers.subtitle': 'الفرص الوظيفية في كرام',
  'careers.text': 'نبحث دائماً عن المواهب المتميزة للانضمام إلى فريقنا المتنامي',
  'careers.benefits.title': 'مميزات العمل في كرام',
  'careers.positions.title': 'الوظائف المتاحة',
  'careers.apply.title': 'كيفية التقديم',
  'careers.apply.text': 'يرجى إرسال سيرتك الذاتية ورسالة تعريفية إلى careers@cram-global.com',
  
  // Insights
  'insights.title': 'الرؤى والأخبار',
  'insights.subtitle': 'آخر التحديثات والمقالات والتقارير',
  'insights.categories.all': 'الكل',
  'insights.categories.articles': 'المقالات',
  'insights.categories.news': 'الأخبار',
  'insights.categories.reports': 'التقارير',
  'insights.categories.whitepapers': 'الأوراق البيضاء',
  'insights.readmore': 'اقرأ المزيد',
  'insights.date': 'نُشر في',
  
  // 404
  '404.title': 'الصفحة غير موجودة',
  '404.text': 'عذراً، الصفحة التي تبحث عنها غير موجودة',
  '404.button': 'العودة للرئيسية',
  
  // General
  'general.learnMore': 'اعرف المزيد',
  'general.readMore': 'اقرأ المزيد',
  'general.viewAll': 'عرض الكل',
  'general.loading': 'جارٍ التحميل...',
  'general.required': 'مطلوب',
  'general.or': 'أو',
  'general.and': 'و',
};